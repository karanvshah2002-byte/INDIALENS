# MarketLens — live sector rotation + scans (free, self-hosted)

Auto-updating every 30 min during NSE market hours. No server, no paid data.

## Setup (10 minutes, one time)

1. **Create a GitHub repo** (public) and upload all these files, keeping the folder structure.
2. **Enable Actions write access**: repo → Settings → Actions → General → Workflow permissions → select **"Read and write permissions"** → Save.
3. **Run it once**: repo → Actions → "Update market data" → **Run workflow**. Wait ~2 min; it commits a fresh `data.json`.
4. **Turn on GitHub Pages**: Settings → Pages → Source: **Deploy from a branch** → Branch: `main`, folder `/ (root)` → Save.
5. Your dashboard is live at `https://<your-username>.github.io/<repo-name>/`

That's it. It now refreshes itself every 30 min, 9:15am–3:35pm IST, Mon–Fri.

## Customize

- **Add/remove sectors or stocks**: edit `SECTOR_MAP` in `pipeline/update_data.py` (ticker format: `SYMBOL.NS`).
- **Change update frequency**: edit the cron lines in `.github/workflows/update-data.yml` (times are UTC = IST − 5:30).
- **Methodology**: RS = sector 3M return − NIFTY 500 3M return; Momentum = 1M change in RS; Score = average of the two. Sectors are equal-weighted baskets of their members.

## Notes

- Data via Yahoo Finance, ~15 min delayed. Good enough for rotation analysis; not for scalping.
- GitHub Actions free tier easily covers this schedule (~65 runs/week, ~2 min each).
- If a run fails (Yahoo hiccup), the site keeps showing the last good data.json.

"""
MarketLens data pipeline
Pulls delayed NSE prices via yfinance, computes sector RS/momentum
vs NIFTY 500, and writes data.json for the dashboard.
Run by GitHub Actions every 30 min during market hours (IST).
"""

import json
import sys
from datetime import datetime, timezone, timedelta

import numpy as np
import pandas as pd
import yfinance as yf

IST = timezone(timedelta(hours=5, minutes=30))

# ---------------- Universe: sector -> [(yahoo_ticker, symbol, name)] ----------------
# Edit freely. Add/remove sectors and members — everything downstream adapts.
SECTOR_MAP = {
    "Jewellery": [("KALYANKJIL.NS", "KALYANKJIL", "Kalyan Jewellers"), ("TITAN.NS", "TITAN", "Titan Company"), ("SENCO.NS", "SENCO", "Senco Gold")],
    "NBFC": [("BAJFINANCE.NS", "BAJFINANCE", "Bajaj Finance"), ("CHOLAFIN.NS", "CHOLAFIN", "Cholamandalam"), ("SHRIRAMFIN.NS", "SHRIRAMFIN", "Shriram Finance")],
    "Real Estate": [("DLF.NS", "DLF", "DLF"), ("LODHA.NS", "LODHA", "Macrotech"), ("PRESTIGE.NS", "PRESTIGE", "Prestige Estates")],
    "Hospitals": [("APOLLOHOSP.NS", "APOLLOHOSP", "Apollo Hospitals"), ("MAXHEALTH.NS", "MAXHEALTH", "Max Healthcare"), ("FORTIS.NS", "FORTIS", "Fortis Healthcare")],
    "Chemicals": [("NAVINFLUOR.NS", "NAVINFLUOR", "Navin Fluorine"), ("SRF.NS", "SRF", "SRF"), ("PIIND.NS", "PIIND", "PI Industries")],
    "New Age Internet": [("PAYTM.NS", "PAYTM", "One97 Comm"), ("ETERNAL.NS", "ETERNAL", "Eternal (Zomato)"), ("NYKAA.NS", "NYKAA", "Nykaa")],
    "Telecom": [("BHARTIARTL.NS", "BHARTIARTL", "Bharti Airtel"), ("IDEA.NS", "IDEA", "Vodafone Idea"), ("INDUSTOWER.NS", "INDUSTOWER", "Indus Towers")],
    "Auto": [("TATAMOTORS.NS", "TATAMOTORS", "Tata Motors"), ("M&M.NS", "M&M", "Mahindra & Mahindra"), ("MARUTI.NS", "MARUTI", "Maruti Suzuki")],
    "Auto Ancillary": [("UNOMINDA.NS", "UNOMINDA", "Uno Minda"), ("SUPRAJIT.NS", "SUPRAJIT", "Suprajit Eng"), ("SONACOMS.NS", "SONACOMS", "Sona BLW")],
    "Metal": [("JSWSTEEL.NS", "JSWSTEEL", "JSW Steel"), ("TATASTEEL.NS", "TATASTEEL", "Tata Steel"), ("HINDALCO.NS", "HINDALCO", "Hindalco")],
    "Pharma": [("SUNPHARMA.NS", "SUNPHARMA", "Sun Pharma"), ("DRREDDY.NS", "DRREDDY", "Dr Reddy's"), ("CIPLA.NS", "CIPLA", "Cipla")],
    "Insurance": [("SBILIFE.NS", "SBILIFE", "SBI Life"), ("HDFCLIFE.NS", "HDFCLIFE", "HDFC Life"), ("ICICIGI.NS", "ICICIGI", "ICICI Lombard")],
    "PSU Banks": [("SBIN.NS", "SBIN", "State Bank of India"), ("UNIONBANK.NS", "UNIONBANK", "Union Bank"), ("BANKBARODA.NS", "BANKBARODA", "Bank of Baroda")],
    "Private Banks": [("ICICIBANK.NS", "ICICIBANK", "ICICI Bank"), ("HDFCBANK.NS", "HDFCBANK", "HDFC Bank"), ("KOTAKBANK.NS", "KOTAKBANK", "Kotak Bank")],
    "EMS": [("SYRMA.NS", "SYRMA", "Syrma SGS"), ("KAYNES.NS", "KAYNES", "Kaynes Tech"), ("DIXON.NS", "DIXON", "Dixon Tech")],
    "Cement": [("ULTRACEMCO.NS", "ULTRACEMCO", "UltraTech"), ("SHREECEM.NS", "SHREECEM", "Shree Cement"), ("AMBUJACEM.NS", "AMBUJACEM", "Ambuja Cements")],
    "FMCG": [("HINDUNILVR.NS", "HINDUNILVR", "Hindustan Unilever"), ("NESTLEIND.NS", "NESTLEIND", "Nestle India"), ("ITC.NS", "ITC", "ITC")],
    "Defence": [("HAL.NS", "HAL", "Hindustan Aeronautics"), ("BEL.NS", "BEL", "Bharat Electronics"), ("BDL.NS", "BDL", "Bharat Dynamics")],
    "Hotels": [("INDHOTEL.NS", "INDHOTEL", "Indian Hotels"), ("EIHOTEL.NS", "EIHOTEL", "EIH"), ("CHALET.NS", "CHALET", "Chalet Hotels")],
    "IT": [("TCS.NS", "TCS", "TCS"), ("INFY.NS", "INFY", "Infosys"), ("LTIM.NS", "LTIM", "LTIMindtree")],
    "IT Midcap": [("PERSISTENT.NS", "PERSISTENT", "Persistent"), ("COFORGE.NS", "COFORGE", "Coforge"), ("OFSS.NS", "OFSS", "Oracle Fin Services")],
    "Capital Goods": [("LT.NS", "LT", "Larsen & Toubro"), ("SIEMENS.NS", "SIEMENS", "Siemens"), ("BHEL.NS", "BHEL", "BHEL")],
    "Power": [("NTPC.NS", "NTPC", "NTPC"), ("ADANIPOWER.NS", "ADANIPOWER", "Adani Power"), ("TATAPOWER.NS", "TATAPOWER", "Tata Power")],
    "Renewables": [("ADANIGREEN.NS", "ADANIGREEN", "Adani Green"), ("SUZLON.NS", "SUZLON", "Suzlon Energy"), ("INOXWIND.NS", "INOXWIND", "Inox Wind")],
    "Oil & Gas": [("RELIANCE.NS", "RELIANCE", "Reliance"), ("ONGC.NS", "ONGC", "ONGC"), ("GAIL.NS", "GAIL", "GAIL")],
    "Railways": [("IRFC.NS", "IRFC", "IRFC"), ("RVNL.NS", "RVNL", "RVNL"), ("TITAGARH.NS", "TITAGARH", "Titagarh Rail")],
    "Logistics": [("DELHIVERY.NS", "DELHIVERY", "Delhivery"), ("CONCOR.NS", "CONCOR", "Container Corp"), ("BLUEDART.NS", "BLUEDART", "Blue Dart")],
    "Retail": [("TRENT.NS", "TRENT", "Trent"), ("DMART.NS", "DMART", "Avenue Supermarts"), ("VMART.NS", "VMART", "V-Mart Retail")],
    "Consumer Durables": [("VOLTAS.NS", "VOLTAS", "Voltas"), ("HAVELLS.NS", "HAVELLS", "Havells"), ("BLUESTARCO.NS", "BLUESTARCO", "Blue Star")],
    "Media": [("PVRINOX.NS", "PVRINOX", "PVR Inox"), ("ZEEL.NS", "ZEEL", "Zee Entertainment"), ("SUNTV.NS", "SUNTV", "Sun TV")],
}

BENCHMARKS = {"^CRSLDX": "NIFTY 500", "^NSEI": "NIFTY 50"}  # first available wins
HEADER_INDICES = [("^NSEI", "NIFTY 50"), ("^BSESN", "SENSEX"), ("^NSEBANK", "BANK NIFTY"), ("^INDIAVIX", "INDIA VIX")]

RS_LOOKBACK = 63   # ~3 months
MOM_LOOKBACK = 21  # ~1 month


def pct(series, n):
    """% change over n trading days (last value vs n-back)."""
    s = series.dropna()
    if len(s) <= n:
        return 0.0
    return float((s.iloc[-1] / s.iloc[-1 - n] - 1) * 100)


def main():
    all_tickers = [t for members in SECTOR_MAP.values() for (t, _, _) in members]
    fetch = sorted(set(all_tickers)) + list(BENCHMARKS) + [t for t, _ in HEADER_INDICES]

    print(f"Downloading {len(fetch)} tickers…")
    raw = yf.download(fetch, period="1y", interval="1d", auto_adjust=True,
                      group_by="ticker", threads=True, progress=False)

    def closes(t):
        try:
            return raw[t]["Close"].dropna()
        except Exception:
            return pd.Series(dtype=float)

    def volumes(t):
        try:
            return raw[t]["Volume"].dropna()
        except Exception:
            return pd.Series(dtype=float)

    # ---- benchmark ----
    bench, bench_name = None, None
    for sym, name in BENCHMARKS.items():
        c = closes(sym)
        if len(c) > RS_LOOKBACK + MOM_LOOKBACK:
            bench, bench_name = c, name
            break
    if bench is None:
        sys.exit("No benchmark data — aborting (keeping previous data.json).")

    # ---- header indices ----
    indices = []
    for sym, name in HEADER_INDICES:
        c = closes(sym)
        if len(c) >= 2:
            indices.append({"name": name, "val": round(float(c.iloc[-1]), 2), "chg": round(pct(c, 1), 2)})

    # ---- sectors ----
    sectors, stocks = [], []
    for sector, members in SECTOR_MAP.items():
        series, member_rows = [], []
        for tick, sym, name in members:
            c, v = closes(tick), volumes(tick)
            if len(c) < RS_LOOKBACK + MOM_LOOKBACK + 5:
                print(f"  skip {tick} (insufficient history)")
                continue
            series.append(c / c.iloc[0])  # normalize for equal-weight index
            vol_ratio = float(v.iloc[-1] / v.iloc[-21:-1].mean()) if len(v) > 22 and v.iloc[-21:-1].mean() > 0 else 1.0
            hi52 = float(c.iloc[-252:].max()) if len(c) else float(c.max())
            member_rows.append({
                "sym": sym, "name": name, "sector": sector,
                "price": round(float(c.iloc[-1]), 2),
                "d1": round(pct(c, 1), 2), "w1": round(pct(c, 5), 2), "m1": round(pct(c, 21), 2),
                "vol": round(vol_ratio, 1),
                "off52": round((float(c.iloc[-1]) / hi52 - 1) * 100, 1),
            })
        if not series:
            continue

        idx = pd.concat(series, axis=1).dropna().mean(axis=1)
        common = idx.index.intersection(bench.index)
        idx_a, bench_a = idx.loc[common], bench.loc[common]

        # RS = sector 3M return minus benchmark 3M return (in % points)
        rs_series = (idx_a / idx_a.shift(RS_LOOKBACK) - 1) * 100 - (bench_a / bench_a.shift(RS_LOOKBACK) - 1) * 100
        rs_series = rs_series.dropna()
        if len(rs_series) < MOM_LOOKBACK + 2:
            continue
        rs = float(rs_series.iloc[-1])
        mom = float(rs_series.iloc[-1] - rs_series.iloc[-1 - MOM_LOOKBACK])
        score = (rs + mom) / 2

        best = max(member_rows, key=lambda r: r["w1"]) if member_rows else None
        sectors.append({
            "name": sector,
            "score": round(score, 1), "rs": round(rs, 1), "mom": round(mom, 1),
            "w1": round(pct(idx_a, 5), 1), "m1": round(pct(idx_a, 21), 1), "m3": round(pct(idx_a, 63), 1),
            "top": best["sym"] if best else "",
        })
        stocks.extend(member_rows)

    if not sectors:
        sys.exit("No sector data computed — aborting.")

    out = {
        "updated": datetime.now(IST).strftime("%d %b %Y, %I:%M %p IST"),
        "benchmark": bench_name,
        "indices": indices,
        "sectors": sorted(sectors, key=lambda s: -s["score"]),
        "stocks": stocks,
    }
    with open("data.json", "w") as f:
        json.dump(out, f, indent=1)
    print(f"Wrote data.json: {len(sectors)} sectors, {len(stocks)} stocks, benchmark {bench_name}")


if __name__ == "__main__":
    main()
